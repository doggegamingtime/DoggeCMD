# DoggeCMD - A Py-Based command line
Hello there! This is DoggeCMD, a Py-Based command line.
## What is DoggeCMD?
DoggeCMD is a Py-Based command line which features a variety of tools; starting with the SOS tool, which intergrates with **HIS**. To use DoggeCMD, click [here](https://doggegamingtime.github.io/DoggeCMD). If that doesn't work, click [here](https://doggegaming.repl.co/DoggeCMD) instead.
### When you think DoggeCMD is poggers
Please be greatful.